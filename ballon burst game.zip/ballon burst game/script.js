const pumpButton = document.getElementById("pumpButton");
const gameCanvas = document.getElementById("gameCanvas");

// Balloon properties
const balloonImages = [
  "./img/yellow.png",
  "./img/orenge.png",
  "./img/green.png",
  "./img/blue.png",
  './img/bluewave.png',
  './img/orange2.png',
  './img/pink.png',
  './img/purple.png',
  './img/purpleheart.png',
  './img/red.png'
];
const alphabetImages = [
  "./img/Symbol 10001.png",
  "./img/Symbol 10022.png",
  "./img/Symbol 10023.png",
  "./img/Symbol 10021.png",
  "./img/Symbol 10002.png",
  "./img/Symbol 10003.png",
  "./img/Symbol 10004.png",
  "./img/Symbol 10005.png",
  "./img/Symbol 10006.png",
  "./img/Symbol 10007.png",
  "./img/Symbol 10008.png",
  "./img/Symbol 10009.png",
  "./img/Symbol 10010.png",
];
const balloonSize = 200;
const burstDelay = 15000; // 8 seconds

// Fixed position for the balloons
const balloonPosition = { left: 920, top: 280 };

// Event listener for pump button click
pumpButton.addEventListener("click", createBalloon);

// Function to create a balloon
function createBalloon() {
  const balloonContainer = document.createElement("div");
  const randomBalloonImage = balloonImages[Math.floor(Math.random() * balloonImages.length)];
  const randomAlphabetImage = alphabetImages[Math.floor(Math.random() * alphabetImages.length)];

  balloonContainer.classList.add("balloon-container");
  balloonContainer.style.width = `${balloonSize}px`;
  balloonContainer.style.height = `${balloonSize}px`;

  const balloonImage = document.createElement("div");
  balloonImage.classList.add("balloon-image");
  balloonImage.style.backgroundImage = `url('${randomBalloonImage}')`;

  const alphabetImage = document.createElement("img");
  alphabetImage.classList.add("alphabet-image");
  alphabetImage.src = randomAlphabetImage;

  balloonImage.appendChild(alphabetImage);

  const stringImage = document.createElement("img");
  stringImage.classList.add("string-image");
  stringImage.src = "./img/string.png";

  balloonContainer.style.left = `${balloonPosition.left}px`;
  balloonContainer.style.top = `${balloonPosition.top}px`;


  balloonContainer.appendChild(stringImage);

  balloonContainer.appendChild(balloonImage);

  gameCanvas.appendChild(balloonContainer);

  // Random movement
  const randomSpeedX = Math.floor(Math.random() * 3) + 1;
  const randomSpeedY = Math.floor(Math.random() * 3) + 1;
  const randomDirectionX = Math.random() < 0.5 ? -1 : 1;
  const randomDirectionY = Math.random() < 0.5 ? -1 : 1;

  let posX = balloonPosition.left;
  let posY = balloonPosition.top;
  let isBurst = false; // Add a flag to track the balloon burst status

  const intervalId = setInterval(() => {
    if (isBurst) return; // If the balloon is already burst, exit the interval

    posX += randomDirectionX * randomSpeedX;
    posY += randomDirectionY * randomSpeedY;

    balloonContainer.style.left = `${posX}px`;
    balloonContainer.style.top = `${posY}px`;

    // Check boundaries
    if (posX < 0 || posX > gameCanvas.clientWidth - balloonSize || posY < 0 || posY > gameCanvas.clientHeight - balloonSize) {
      burstBalloon(balloonContainer);
      clearInterval(intervalId); // Stop the interval when bursting the balloon
    }
  }, 50);

  setTimeout(() => burstBalloon(balloonContainer, intervalId), burstDelay);
}


// function burstBalloon(balloonContainer, intervalId) {
//   balloonContainer.classList.add("burst");
//   setTimeout(() => {
//     gameCanvas.removeChild(balloonContainer);
//     clearInterval(intervalId); // Stop the interval if it hasn't been cleared yet
//   }, 1000);
// }

// Function to burst a balloon
function burstBalloon(balloonContainer) {
  const balloonImage = balloonContainer.querySelector(".balloon-image");

  // Create burst animation element
  const burstAnimation = document.createElement("div");
  burstAnimation.classList.add("burst-animation");

  // Add the burst animation element to the game canvas
  balloonContainer.appendChild(burstAnimation);

  // Remove the balloon after the burst animation
  setTimeout(() => {
    gameCanvas.removeChild(balloonContainer);
  }, 1000);
}
